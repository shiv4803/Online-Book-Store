package com.BookStore.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.*;

import com.BookStore.model.Book;
import com.BookStore.repository.BookRepository;

@Controller
public class BookController 
{
    @Autowired
    private BookRepository bookRepo;

    // Home page
    @GetMapping("/")
    public String home() 
    {
        return "home";
    }

    // Show book register form
    @GetMapping("/register")
    public String showForm(Model model) 
    {
        model.addAttribute("book", new Book());
        return "bookRegister";
    }
    
    // Save book    
    @PostMapping("/save")
    public String saveBook(@ModelAttribute Book book) 
    {
        bookRepo.save(book);
        return "redirect:/books";
    }
    
   // View all books
   @GetMapping("/books")
   public String viewAllBooks(Model model) 
   {
	   List<Book> list = bookRepo.findAll();
       model.addAttribute("books", list);
       return "BookList"; // maps to BookList.html
   }
   
  // Search by title
   @GetMapping("/search")    
   public String searchBooks(@RequestParam(value ="title", required = true)String title, Model model)
   {
	   List<Book> results = bookRepo.findByTitleContainingIgnoreCase(title);
	   if (!results.isEmpty()) {
	       // ✅ Match Found
	       model.addAttribute("books", results);
	       model.addAttribute("message", "Match found for: " + title);
	       return "BookList";
	   } else {
	       // ❌ No Match Found
	       model.addAttribute("errorMessage", "No match found for title: " + title);
	       return "errorPage";
	   }
   }


// // 3. View a single book by ID (optional, for edit page)
//   @GetMapping("/book/{id}")
//   public String getBookById(@PathVariable("id") long id, Model model)
//   {
//	   Optional<Book> optionalBook = bookRepo.findById(id);
//	   if (optionalBook.isPresent()) 
//	   {
//		   model.addAttribute("book", optionalBook.get());
//           return "BookEdit"; // if you have BookEdit.html
//	   }
//       else {
//    	   model.addAttribute("errorMessage", "Book with ID " + id + " not found.");
//           return "errorPage";
//       }
//   }
   
    @GetMapping("/edit/{id}")
    public String editBook(@PathVariable Long id, Model model) 
    {
        Book book = bookRepo.findById(id).orElse(null);
        model.addAttribute("book", book);
        return "BookEdit";
    }

    @PostMapping("/update/{id}")
    public String updateBook(@PathVariable Long id, @ModelAttribute Book book) 
    {
        book.setId(id);
        bookRepo.save(book);
        return "redirect:/books";
    }

    @GetMapping("/delete/{id}")
    public String deleteBook(@PathVariable Long id) 
    {
        bookRepo.deleteById(id);
        return "redirect:/books";
    }
}

