package com.BookStore.repository;

import java.util.*;

import org.springframework.data.jpa.repository.JpaRepository;

import com.BookStore.model.Book;

public interface BookRepository extends JpaRepository<Book, Long> 
{
	List<Book> findByTitleContainingIgnoreCase(String title);

}
